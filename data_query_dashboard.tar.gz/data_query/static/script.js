class AnalyticsDashboard {
    constructor() {
        this.chart = null;
        this.currentData = null;
        this.init();
    }

    init() {
        // Set up event listeners
        document.getElementById('queryForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.submitQuery();
        });

        // Sample query buttons
        document.querySelectorAll('.sample-query').forEach(btn => {
            btn.addEventListener('click', () => {
                document.getElementById('queryInput').value = btn.textContent.trim();
            });
        });

        // View toggle buttons
        document.getElementById('chartView').addEventListener('change', () => {
            if (this.currentData) this.showChart();
        });

        document.getElementById('tableView').addEventListener('change', () => {
            if (this.currentData) this.showTable();
        });

        // Load dataset information
        this.loadDatasetInfo();
    }

    async loadDatasetInfo() {
        try {
            const response = await fetch('/data-info');
            if (response.ok) {
                const info = await response.json();
                document.getElementById('datasetDetails').innerHTML = `
                    <div><strong>Columns:</strong> ${info.columns.join(', ')}</div>
                    <div><strong>Records:</strong> ${info.row_count.toLocaleString()}</div>
                    <div><strong>Date Range:</strong> ${new Date(info.date_range.start).toLocaleDateString()} - ${new Date(info.date_range.end).toLocaleDateString()}</div>
                    <div><strong>Regions:</strong> ${info.regions.join(', ')}</div>
                `;
            } else {
                document.getElementById('datasetDetails').innerHTML = 'Failed to load dataset information';
            }
        } catch (error) {
            document.getElementById('datasetDetails').innerHTML = 'Error loading dataset information';
        }
    }

    async submitQuery() {
        const query = document.getElementById('queryInput').value.trim();
        if (!query) return;

        this.showLoading();

        try {
            const response = await fetch('/ask', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ query: query })
            });

            const data = await response.json();

            if (data.success) {
                this.currentData = data;
                this.showResults();
            } else {
                this.showError(data.error || 'Unknown error occurred');
            }
        } catch (error) {
            this.showError('Network error: ' + error.message);
        }
    }

    showLoading() {
        this.hideAllStates();
        document.getElementById('loadingState').style.display = 'block';
    }

    showError(message) {
        this.hideAllStates();
        document.getElementById('errorMessage').textContent = message;
        document.getElementById('errorState').style.display = 'block';
    }

    showResults() {
        this.hideAllStates();
        document.getElementById('viewToggle').style.display = 'block';
        document.getElementById('queryInfo').style.display = 'block';
        document.getElementById('executedQuery').textContent = this.currentData.query;

        // Default to chart view
        document.getElementById('chartView').checked = true;
        this.showChart();
    }

    hideAllStates() {
        document.getElementById('loadingState').style.display = 'none';
        document.getElementById('emptyState').style.display = 'none';
        document.getElementById('errorState').style.display = 'none';
        document.getElementById('chartContainer').style.display = 'none';
        document.getElementById('tableContainer').style.display = 'none';
        document.getElementById('viewToggle').style.display = 'none';
        document.getElementById('queryInfo').style.display = 'none';
    }

    showChart() {
        document.getElementById('chartContainer').style.display = 'block';
        document.getElementById('tableContainer').style.display = 'none';
        this.renderChart();
    }

    showTable() {
        document.getElementById('tableContainer').style.display = 'block';
        document.getElementById('chartContainer').style.display = 'none';
        this.renderTable();
    }

    renderChart() {
        const result = this.currentData.result;
        const ctx = document.getElementById('resultChart').getContext('2d');

        // Destroy existing chart
        if (this.chart) {
            this.chart.destroy();
        }

        if (result.type === 'scalar') {
            // For scalar values, show a simple metric card
            document.getElementById('chartContainer').innerHTML = `
                <div class="text-center py-5">
                    <h2 class="display-4 text-primary">${this.formatNumber(result.data)}</h2>
                    <p class="text-muted">Result</p>
                </div>
            `;
            return;
        }

        // Recreate canvas
        document.getElementById('chartContainer').innerHTML = '<canvas id="resultChart"></canvas>';
        const newCtx = document.getElementById('resultChart').getContext('2d');

        let chartData = null;
        let chartConfig = null;

        if (result.type === 'dataframe' && result.data.length > 0) {
            chartData = this.prepareChartData(result);
            chartConfig = this.getChartConfig(chartData, result);
        } else if (result.type === 'series') {
            chartData = this.prepareSeriesData(result);
            chartConfig = this.getChartConfig(chartData, result);
        }

        if (chartConfig) {
            this.chart = new Chart(newCtx, chartConfig);
        } else {
            document.getElementById('chartContainer').innerHTML = `
                <div class="text-center py-5">
                    <i class="fas fa-chart-bar fa-3x text-muted mb-3"></i>
                    <h5 class="text-muted">Cannot visualize this data</h5>
                    <p class="text-muted">Try the table view to see the raw data.</p>
                </div>
            `;
        }
    }

    prepareChartData(result) {
        const data = result.data;
        const columns = result.columns;

        // Try to identify label and value columns
        let labelCol = null;
        let valueCol = null;

        // Look for common label column names
        const labelCandidates = ['region', 'date', 'month', 'year', 'category', 'name'];
        const valueCandidates = ['sales', 'amount', 'total', 'count', 'value'];

        for (const col of columns) {
            if (labelCandidates.some(candidate => col.toLowerCase().includes(candidate))) {
                labelCol = col;
                break;
            }
        }

        for (const col of columns) {
            if (valueCandidates.some(candidate => col.toLowerCase().includes(candidate)) || 
                typeof data[0]?.[col] === 'number') {
                valueCol = col;
                break;
            }
        }

        // Fallback: use first non-numeric for labels, first numeric for values
        if (!labelCol) labelCol = columns[0];
        if (!valueCol) {
            valueCol = columns.find(col => typeof data[0]?.[col] === 'number') || columns[1];
        }

        return {
            labels: data.map(row => String(row[labelCol])),
            values: data.map(row => Number(row[valueCol]) || 0),
            labelCol,
            valueCol
        };
    }

    prepareSeriesData(result) {
        const data = result.data;
        return {
            labels: Object.keys(data),
            values: Object.values(data).map(v => Number(v) || 0),
            labelCol: 'Category',
            valueCol: result.name || 'Value'
        };
    }

    getChartConfig(chartData, result) {
        const isTimeSeries = chartData.labels.some(label => 
            /\d{4}-\d{2}|\d{4}\/\d{2}|\d{2}\/\d{4}/.test(label)
        );

        const chartType = isTimeSeries ? 'line' : 
                          chartData.labels.length > 10 ? 'bar' : 'bar';

        return {
            type: chartType,
            data: {
                labels: chartData.labels,
                datasets: [{
                    label: chartData.valueCol,
                    data: chartData.values,
                    backgroundColor: chartType === 'line' ? 'rgba(13, 110, 253, 0.1)' : 'rgba(13, 110, 253, 0.8)',
                    borderColor: 'rgba(13, 110, 253, 1)',
                    borderWidth: 2,
                    fill: chartType === 'line'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    title: {
                        display: true,
                        text: this.currentData.query
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return typeof value === 'number' ? value.toLocaleString() : value;
                            }
                        }
                    },
                    x: {
                        ticks: {
                            maxRotation: 45
                        }
                    }
                }
            }
        };
    }

    renderTable() {
        const result = this.currentData.result;
        const table = document.getElementById('resultTable');
        const thead = table.querySelector('thead');
        const tbody = table.querySelector('tbody');

        thead.innerHTML = '';
        tbody.innerHTML = '';

        if (result.type === 'scalar') {
            thead.innerHTML = '<tr><th>Result</th></tr>';
            tbody.innerHTML = `<tr><td>${this.formatNumber(result.data)}</td></tr>`;
            return;
        }

        if (result.type === 'series') {
            thead.innerHTML = '<tr><th>Category</th><th>Value</th></tr>';
            Object.entries(result.data).forEach(([key, value]) => {
                const row = tbody.insertRow();
                row.insertCell(0).textContent = key;
                row.insertCell(1).textContent = this.formatNumber(value);
            });
            return;
        }

        if (result.type === 'dataframe' && result.data.length > 0) {
            // Table headers
            const headerRow = thead.insertRow();
            result.columns.forEach(col => {
                const th = document.createElement('th');
                th.textContent = col;
                headerRow.appendChild(th);
            });

            // Table rows
            result.data.forEach(row => {
                const tr = tbody.insertRow();
                result.columns.forEach(col => {
                    const cell = tr.insertCell();
                    const value = row[col];
                    cell.textContent = typeof value === 'number' ? this.formatNumber(value) : value;
                });
            });
        }
    }

    formatNumber(value) {
        if (typeof value !== 'number') return value;
        if (Number.isInteger(value)) {
            return value.toLocaleString();
        } else {
            return value.toLocaleString(undefined, { maximumFractionDigits: 2 });
        }
    }
}

// Initialize the dashboard when the page loads
document.addEventListener('DOMContentLoaded', () => {
    new AnalyticsDashboard();
});
